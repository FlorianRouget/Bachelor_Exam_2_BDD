-- phpMyAdmin SQL Dump
-- version 4.5.3.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 23 Mars 2017 à 17:39
-- Version du serveur :  5.7.10
-- Version de PHP :  5.6.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `exam3_bdd_android`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `ID_CLIENT` int(11) NOT NULL,
  `NOM` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `PRENOM` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `SOCIETE` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `TEL` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `MAIL` varchar(20) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`ID_CLIENT`, `NOM`, `PRENOM`, `SOCIETE`, `TEL`, `MAIL`) VALUES
(1, 'Nom', 'Prenom', 'Entreprise', '0101010101', 'nom.prenom@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `note_suivi`
--

CREATE TABLE `note_suivi` (
  `ID_NOTE` int(11) NOT NULL,
  `N_NOTE` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `CONTENT` text COLLATE latin1_general_ci NOT NULL,
  `DATE_NOTE` date NOT NULL,
  `#ID_PROJET` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `participe`
--

CREATE TABLE `participe` (
  `#ID_USER` int(11) NOT NULL,
  `#ID_PROJET` int(11) NOT NULL,
  `FONCTION` varchar(30) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Contenu de la table `participe`
--

INSERT INTO `participe` (`#ID_USER`, `#ID_PROJET`, `FONCTION`) VALUES
(1, 1, 'CDP'),
(1, 2, 'GameDesigner'),
(2, 1, 'Developpeur'),
(2, 2, 'Developpeur'),
(6, 1, 'Observateur');

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

CREATE TABLE `projet` (
  `ID_PROJET` int(11) NOT NULL,
  `N_PROJET` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `DESC_PROJET` text COLLATE latin1_general_ci NOT NULL,
  `TYPE` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `LANGAGE` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `BUDGET` double NOT NULL,
  `#ID_CLIENT` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Contenu de la table `projet`
--

INSERT INTO `projet` (`ID_PROJET`, `N_PROJET`, `DESC_PROJET`, `TYPE`, `LANGAGE`, `BUDGET`, `#ID_CLIENT`) VALUES
(1, 'Projet1', 'sfdsf ssdf  sf dsfds fsdf dfsdfsd sdfsdfsdf sfsdfsdff s fd sdf dfsdfsd ', 'AppliMobile', 'Java', 5000, 1),
(2, 'Projet2', 'dfsdf sdfdfsdfd sfdfdsfdsf sdf sdf sd dsfsdfesefesfds', 'VideoGame', 'C#', 10000, 1);

-- --------------------------------------------------------

--
-- Structure de la table `step`
--

CREATE TABLE `step` (
  `ID_STEP` int(11) NOT NULL,
  `N_STEP` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `DESC_STEP` text COLLATE latin1_general_ci NOT NULL,
  `DATE_DEBUT` date NOT NULL,
  `DUREE` int(11) NOT NULL,
  `#ID_PROJET` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `ID_USER` int(11) NOT NULL,
  `LOGIN` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `PASSWORD` varchar(100) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`ID_USER`, `LOGIN`, `PASSWORD`) VALUES
(1, 'FirstLogin', 'FirstPassword'),
(2, 'SecondLogin', 'SecondPassword'),
(6, 'Your Login', 'Password'),
(7, 'L', 'Password');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`ID_CLIENT`);

--
-- Index pour la table `note_suivi`
--
ALTER TABLE `note_suivi`
  ADD PRIMARY KEY (`ID_NOTE`);

--
-- Index pour la table `participe`
--
ALTER TABLE `participe`
  ADD PRIMARY KEY (`#ID_USER`,`#ID_PROJET`);

--
-- Index pour la table `projet`
--
ALTER TABLE `projet`
  ADD PRIMARY KEY (`ID_PROJET`);

--
-- Index pour la table `step`
--
ALTER TABLE `step`
  ADD PRIMARY KEY (`ID_STEP`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID_USER`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `ID_CLIENT` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `note_suivi`
--
ALTER TABLE `note_suivi`
  MODIFY `ID_NOTE` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `projet`
--
ALTER TABLE `projet`
  MODIFY `ID_PROJET` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `step`
--
ALTER TABLE `step`
  MODIFY `ID_STEP` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `ID_USER` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
